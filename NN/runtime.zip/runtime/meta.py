#!/usr/bin/env python3

""" Мета-данные проекта.
"""

# Версия проекта.
version: str = "2.8.2"

# Поколение Cortex.
generation: str = "II"
